import React from 'react'
import {createRoot} from 'react-dom/client'
import App from './App'
import './styles.css'
import './analytics'
createRoot(document.getElementById('root')).render(<App/>)
if('serviceWorker' in navigator&&import.meta.env.PROD)addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}))
